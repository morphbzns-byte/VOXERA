VOXERA by morph - native Android project
========================================
Why this replaces the old APK: the old one was a Flutter wrapper that never asked
Android for the microphone (only INTERNET permission) and used a plain WebView, which
has no speech recognition. This project uses Android's own speech recognizer and
declares RECORD_AUDIO, so VOXERA appears under Settings > Apps > Permissions > Microphone
and asks the first time you tap Them or Me.

BUILD OPTION A - Android Studio (PC)
  1. Install Android Studio, choose File > Open, pick this folder, let Gradle sync.
  2. Build > Build Bundle(s) / APK(s) > Build APK(s).
  3. Find it in app/build/outputs/apk/debug/app-debug.apk and install it.

BUILD OPTION B - GitHub (no installs)
  1. Create a free GitHub repository and upload everything in this folder,
     including the hidden .github folder.
  2. Open the Actions tab > "Build VOXERA APK" > Run workflow (it also runs on every push).
  3. When it finishes, download the "VOXERA-apk" artifact, unzip it, install app-debug.apk.

USING IT
  - First tap on Them or Me: allow Microphone.
  - Needs Google speech services (standard on most phones) for voice input. Languages
    must be installed in the phone's speech settings for offline use; online works for all.
  - Translation: free service by default; the gear icon lets you add your own Anthropic key.
  - Some phones silence third-party mics during a normal phone call. VoIP calls on
    speaker (WhatsApp etc.) or a second phone work more reliably.
